export const formatName = (name) => name.split('_').map(_namePart => {
  const namePart = _namePart.trim();
  if (namePart === '') {
    return '';
  }

  return namePart.charAt(0).toUpperCase() + namePart.slice(1).toLowerCase();
}).filter(val => !!val).join(' ');

const sortFunction = (anime1, anime2) => anime1.anime_name.localeCompare(anime2.anime_name);

export const filterAndSortAnimeList = (search, list) => {
  if (!search || search.trim() === '') {
    return list.sort(sortFunction);
  }

  const criteria = search.trim().split(' ').filter(val => !!val && !val.includes('_'));
  return list.filter(({ anime_name }) => criteria.some(criterion => anime_name.includes(criterion))).sort(sortFunction);
};