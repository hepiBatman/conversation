import React, { useEffect, useState } from 'react';
import { Card } from './Card';
import { filterAndSortAnimeList } from './helpers';

// Request "http://localhost:3000/list"

const AnimeList = () => {
  const [error, setError] = useState('');
  const [animeList, setAnimeList] = useState([]);
  const [filteredAnimeList, setFilteredAnimeList] = useState([]);
  const [filterByName, setFilterByName] = useState('');

  useEffect(() => {
    const updatedAnimeList = filterAndSortAnimeList(filterByName, animeList);
    setFilteredAnimeList(updatedAnimeList);
  }, [filterByName, animeList]);

  useEffect(() => {
    if (error) {
      return;
    }

    fetch('http://localhost:3000/list')
    .then(response => response.json())
    .then(resp => {
      setAnimeList(resp.data);
      setFilteredAnimeList(filterAndSortAnimeList('', resp.data));
    })
    .catch(() => {
      setError('Error fetching data');
    });
  }, [error]);

  return (
    <div className="animeList">
      {error? (<>
        <h1>{error}</h1>
        <button onClick={() => setError('')}>Retry</button>
      </>) : (<>
        <h1>Anime List</h1>
        Search <input type="text" aria-label="Search" onChange={ev => setFilterByName(ev.target.value)} />
      <div className="cards">
      {filteredAnimeList && filteredAnimeList.map(({anime_id, anime_name, anime_img}) => (
        <Card key={anime_id} name={anime_name} image={anime_img} />
      ))}
      </div>
      </>)}
    </div>
  );
};

export default AnimeList;
